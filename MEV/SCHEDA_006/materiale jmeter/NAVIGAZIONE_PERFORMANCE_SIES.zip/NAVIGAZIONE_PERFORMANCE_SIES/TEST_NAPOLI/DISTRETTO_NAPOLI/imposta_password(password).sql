-- IMPOSTO LA PASSWORD A passoword

update utente  U
set u.pwd='W6ph5Mm5Pz8GgiULbPgzG37mj9g='
WHERE U.COD_UTENTE <>'ADMINNA'
