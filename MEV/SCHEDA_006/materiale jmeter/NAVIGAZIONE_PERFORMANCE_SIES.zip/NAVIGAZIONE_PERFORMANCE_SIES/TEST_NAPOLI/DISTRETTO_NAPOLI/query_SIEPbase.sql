(SELECT 'userid,password,distretto,ChiaveSiepAnno,ChiaveSiepProgressivo,TipoUfficio,SedeUfficio,distrettoUffcio' AS A  FROM DUAL ) 
UNION
SELECT  ''|| COD_OPERATORE_INSERIMENTO ||','||
             'password'||','||
             COD_DISTRETTO ||','||
             CHIAVE_ANNO ||','||
             CHIAVE_PROGR ||','||
             COD_TIPO_UFFICIO ||','||
             DESCR_COMUNE ||','||
             DISTRETTO 
FROM (
      SELECT  F.COD_OPERATORE_INSERIMENTO ,
             'password' ,
             U.COD_DISTRETTO ,
             F.CHIAVE_ANNO ,
             F.CHIAVE_PROGR ,
             U.COD_TIPO_UFFICIO ,
             UF.DESCR_COMUNE ,
             U.COD_DISTRETTO DISTRETTO,
           RANK()  OVER (PARTITION BY F.COD_OPERATORE_INSERIMENTO  ORDER BY F.ID_FASCICOLO_SIEP) AS RNK
        FROM FASCICOLO_SIEP F,
             UFFICIO U,
             UFFICIO_DESCR UF,
             UTENTE UTE
       WHERE U.COD_UFFICIO = F.CHIAVE_UFFICIO
         AND UF.COD_UFFICIO = F.CHIAVE_UFFICIO
         AND UF.COD_UFFICIO = U.COD_UFFICIO
         ---- NON DEVE ESTRARRE I MIGRATI
         AND F.COD_OPERATORE_INSERIMENTO NOT LIKE 'res%'
         -- NON DEVE ESTRARRE I PROVENIENTI DA NSC
         AND F.COD_OPERATORE_INSERIMENTO NOT LIKE 'nsc%'
         AND F.COD_OPERATORE_INSERIMENTO = UTE.COD_UTENTE
         -- UTENTI SENZA DATA FINE VALIDITA
         AND (UTE.DATA_FINE_VALIDITA IS NULL OR
             UTE.DATA_FINE_VALIDITA >= SYSDATE)            
         AND F.COD_OPERATORE_INSERIMENTO IN (SELECT U.COD_UTENTE
            FROM UTENTE_UFFICIO UF, UTENTE U, (SELECT * FROM
            UTENTE_PROFILO PR WHERE PR.PRF_COD_PROFILO <> '90' AND PR.PRF_COD_PROFILO <>
            '99') P WHERE  U.DATA_FINE_VALIDITA IS NULL AND
            P.UTE_COD_UTENTE=U.COD_UTENTE AND UF.UTE_COD_UTENTE=U.COD_UTENTE ) 
          -- DISTRETTO DI NAPOLI           
          AND U.COD_DISTRETTO = '06304900603'              
          -- FASCICOLI DI CLASSE I    
          AND F.CHIAVE_PROGR BETWEEN 1 AND 19999       
)
 WHERE RNK =1
 ORDER BY A DESC
