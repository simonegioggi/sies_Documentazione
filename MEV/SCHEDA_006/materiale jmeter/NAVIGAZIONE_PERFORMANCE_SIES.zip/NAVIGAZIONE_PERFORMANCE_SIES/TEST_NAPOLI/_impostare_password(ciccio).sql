SELECT *  FROM UTENTE U WHERE U.COD_UTENTE <>'ADMINTO'
-- PASSWORD ciccio

update utente  U
set u.pwd='bXzZu8y+mjGbhdpWNLTkEXcn5vA='
WHERE U.COD_UTENTE <>'ADMINTO'
