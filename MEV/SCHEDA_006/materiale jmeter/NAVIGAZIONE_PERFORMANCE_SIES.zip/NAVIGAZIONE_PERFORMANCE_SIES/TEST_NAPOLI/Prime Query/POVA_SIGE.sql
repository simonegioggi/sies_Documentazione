select COD_UTENTE
    from (SELECT u.COD_UTENTE,
                 u.COGNOME,
                 u.NOME,
                 p.PRF_COD_PROFILO,
                 uf.UFF_COD_UFFICIO
            FROM UTENTE_UFFICIO uf,
                 UTENTE u,
                 (SELECT *
                    FROM UTENTE_PROFILO pr
                   WHERE pr.PRF_COD_PROFILO <> '90'
                     AND pr.PRF_COD_PROFILO <> '99') p
           WHERE u.DATA_FINE_VALIDITA is NULL
             AND p.UTE_COD_UTENTE = u.COD_UTENTE
             AND uf.UTE_COD_UTENTE = u.COD_UTENTE
             and p.PRF_COD_PROFILO = '16'
             and u.COD_UTENTE like 'T%'
           ORDER BY DBMS_RANDOM.VALUE)
   where rownum <50
  


SELECT 
 F.chiave_anno,
 F.chiave_progr
  FROM V_FASCICOLO_SIEP F, UTENTE UTE, fascicolo_siep FF,
  
 WHERE FF.ID_FASCICOLO_SIEP = F.id_fascicolo_siep
   AND FF.ID_FASCICOLO_SIEP =
       (SELECT MAX(F3.ID_FASCICOLO_SIEP)
          FROM FASCICOLO_SIEP F3
         WHERE F3.CHIAVE_ANNO = F.chiave_anno
           AND F3.CHIAVE_PROGR = F.CHIAVE_PROGR)
   and F.FLAG_VALIDATO = 'S'
   AND ((F.CHIAVE_ANNO > 2000) OR
       (F.CHIAVE_ANNO = 2000 AND F.CHIAVE_PROGR >= 1))
   AND ((F.CHIAVE_ANNO < 2018) OR
       (F.CHIAVE_ANNO = 2018 AND F.CHIAVE_PROGR <= 19999))
   AND (F.FLAG_VALIDATO = 'S' OR F.FLAG_VALIDATO IS NULL)
   AND ((F.CHIAVE_PROGR BETWEEN 1 AND 19999))
      -- STATO FASCICOLO VALIDATO
   AND F.cod_stato_fascicolo = '03'
      ---- NON DEVE ESTRARRE I MIGRATI
   AND FF.COD_OPERATORE_INSERIMENTO NOT LIKE 'res%'
      -- NON DEVE ESTRARRE I provenienti da nsc
   AND FF.COD_OPERATORE_INSERIMENTO NOT LIKE 'nsc%'
      -- utenti senza data fine validita
   AND (UTE.DATA_FINE_VALIDITA IS NULL OR UTE.DATA_FINE_VALIDITA >= SYSDATE)
   AND FF.COD_OPERATORE_INSERIMENTO = UTE.COD_UTENTE
      -- CONDIZIONE SU DISTRETTO              
   AND F.cod_distretto = '00127200602'
   and rownum < 50
   )
