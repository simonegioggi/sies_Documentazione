--userid,password,ChiaveSiepAnno,ChiaveSiepProgressivo
SELECT 'userid,password,ChiaveSiepAnno,ChiaveSiepProgressivo' AS A  FROM DUAL 
UNION
(SELECT '' || COD_OPERATORE_INSERIMENTO || ',' || 'ciccio' || ',' ||
       chiave_anno || ',' || chiave_progr
  FROM (SELECT DISTINCT FASCICOLO_SIEP.COD_OPERATORE_INSERIMENTO,
                        FASCICOLO_SIEP.CHIAVE_ANNO,
                        FASCICOLO_SIEP.CHIAVE_PROGR,
                        RANK() over(partition by FASCICOLO_SIEP.cod_operatore_inserimento order by FASCICOLO_SIEP.ID_FASCICOLO_SIEP) as rnk
          FROM EVENTO,
               NOTIFICA,
               FASCICOLO_SIEP,
               SOGGETTO,
               UTENTE         UTE,
               ufficio        u
         WHERE EVENTO.FAS_SIE_ID_FASCICOLO_SIEP =
               FASCICOLO_SIEP.ID_FASCICOLO_SIEP
              -- condizioni su utente
              -- and FASCICOLO_SIEP.cod_operatore_inserimento = UTE.COD_UTENTE
              -- utenti senza data fine validita
           AND (UTE.DATA_FINE_VALIDITA IS NULL OR
               UTE.DATA_FINE_VALIDITA >= SYSDATE)
              -- COLLEGAMENTO AL DISTRETTO
           and U.COD_UFFICIO = FASCICOLO_SIEP.CHIAVE_UFFICIO
           AND U.COD_DISTRETTO = '00127200602'
              -- 
           AND FASCICOLO_SIEP.cod_operatore_inserimento in
               (SELECT u.COD_UTENTE
                  FROM UTENTE_UFFICIO uf,
                       UTENTE u,
                       (SELECT *
                          FROM UTENTE_PROFILO pr
                         WHERE pr.PRF_COD_PROFILO <> '90'
                           AND pr.PRF_COD_PROFILO <> '99') p
                 WHERE u.DATA_FINE_VALIDITA is NULL
                   AND p.UTE_COD_UTENTE = u.COD_UTENTE
                   AND uf.UTE_COD_UTENTE = u.COD_UTENTE)
           AND NOTIFICA.EVE_ID_EVENTO = EVENTO.ID_EVENTO
           AND FASCICOLO_SIEP.SOG_ID_SOGGETTO = SOGGETTO.ID_SOGGETTO           
           AND EVENTO.COD_TIPO_PROVVEDIMENTO = '06'
           AND EVENTO.COD_MOTIVO IN
               ('0061', '0062', '0063', '0104', '0105', '0117')
           AND (EVENTO.FLAG_DOCUMENTO_REGISTRATO IS NULL OR
               EVENTO.FLAG_DOCUMENTO_REGISTRATO != 'A')
           AND ((NOTIFICA.COD_TIPO_NOTIFICA = 'E') OR
               (NOTIFICA.COD_TIPO_NOTIFICA = 'N' AND
               NOTIFICA.AVV_ID_AVVOCATO_FASCICOLO_SIEP IS NOT NULL))
           AND NOTIFICA.DATA_AVVENUTA_NOTIFICA IS NULL
              -- fascicolo validato
           AND FASCICOLO_SIEP.COD_STATO_FASCICOLO = '03'
              ---- NON DEVE ESTRARRE I MIGRATI
           AND FASCICOLO_SIEP.COD_OPERATORE_INSERIMENTO NOT LIKE 'res%'
              -- NON DEVE ESTRARRE I provenienti da nsc
           AND FASCICOLO_SIEP.COD_OPERATORE_INSERIMENTO NOT LIKE 'nsc%'
         ORDER BY FASCICOLO_SIEP.COD_OPERATORE_INSERIMENTO,
                  FASCICOLO_SIEP.CHIAVE_ANNO,
                  FASCICOLO_SIEP.CHIAVE_PROGR)
 where rnk = 1)
 order by A desc
